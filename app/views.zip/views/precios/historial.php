<?php
// Variables que entrega PrecioController::historial():
//   $registros, $catalogo, $filtros, $filtrosUrl, $pagina, $totalPaginas, $total

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

/** Muestra la variación porcentual con color y flecha. */
function mostrarVariacion($anterior, $nuevo): string
{
    $variacion = variacionPorcentual($anterior, $nuevo);
    if ($variacion === null) {
        return '<span class="var-flat">—</span>';
    }
    if (abs($variacion) < 0.005) {
        return '<span class="var-flat">0,00 %</span>';
    }
    $clase = $variacion > 0 ? 'var-up' : 'var-down';
    $signo = $variacion > 0 ? '▲ +' : '▼ ';
    return '<span class="' . $clase . '">' . $signo . esc(number_format($variacion, 2, ',', '.')) . ' %</span>';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Precios · POS & Inventario</title>

    <link rel="stylesheet" href="assets/css/sidebar.css" />
    <link rel="stylesheet" href="assets/css/precios.css" />
</head>
<body>

    <?php require_once __DIR__ . '/../layouts/sidebar.php'; ?>

    <main class="main">

        <div class="welcome-card">
            <h1>🕘 Historial de Precios</h1>
            <p>Auditoría de cada cambio de costo y de precio de venta: qué cambió, cuándo y quién lo hizo.</p>
        </div>

        <?= mostrarFlash() ?>

        <div class="prices-list-panel">
            <h3>
                📋 Cambios registrados
                <span class="price-counter"><?= (int) $total ?></span>
            </h3>

            <form method="GET" action="index.php" class="filter-bar">
                <input type="hidden" name="controller" value="precio">
                <input type="hidden" name="action" value="historial">

                <div class="filter-field grow">
                    <label for="id_producto">Producto</label>
                    <select id="id_producto" name="id_producto" class="form-control">
                        <option value="">Todos los productos</option>
                        <?php foreach ($catalogo as $p): ?>
                            <option value="<?= (int) $p['id_producto'] ?>"
                                <?= ((int) ($filtros['id_producto'] ?? 0) === (int) $p['id_producto']) ? 'selected' : '' ?>>
                                <?= esc($p['codigo'] . ' · ' . $p['nombre']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="filter-field">
                    <label for="desde">Desde</label>
                    <input type="date" id="desde" name="desde" class="form-control"
                           max="<?= esc(date('Y-m-d')) ?>" value="<?= esc($filtros['desde'] ?? '') ?>">
                </div>

                <div class="filter-field">
                    <label for="hasta">Hasta</label>
                    <input type="date" id="hasta" name="hasta" class="form-control"
                           max="<?= esc(date('Y-m-d')) ?>" value="<?= esc($filtros['hasta'] ?? '') ?>">
                </div>

                <button type="submit" class="btn-form btn-submit">Filtrar</button>
                <a href="<?= esc(urlAccion('precio', 'historial')) ?>" class="btn-form btn-light">Limpiar</a>
            </form>

            <div class="table-container">
                <table class="prices-table">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Producto</th>
                            <th>Costo</th>
                            <th>Precio de venta</th>
                            <th class="center">Variación venta</th>
                            <th>Origen</th>
                            <th>Usuario</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($registros)): ?>
                            <?php foreach ($registros as $h): ?>
                                <tr>
                                    <td><?= esc(formatoFecha($h['fecha'], true)) ?></td>

                                    <td>
                                        <strong><?= esc($h['nombre_producto']) ?></strong><br>
                                        <span class="badge badge-code"><?= esc($h['codigo']) ?></span>
                                    </td>

                                    <td class="price-change">
                                        <?php if ($h['precio_compra_anterior'] === $h['precio_compra_nuevo']): ?>
                                            <span class="muted"><?= esc(dinero($h['precio_compra_nuevo'])) ?> (sin cambio)</span>
                                        <?php else: ?>
                                            <?= esc(dinero($h['precio_compra_anterior'])) ?><span class="arrow">→</span><strong><?= esc(dinero($h['precio_compra_nuevo'])) ?></strong>
                                        <?php endif; ?>
                                    </td>

                                    <td class="price-change">
                                        <?php if ($h['precio_venta_anterior'] === $h['precio_venta_nuevo']): ?>
                                            <span class="muted"><?= esc(dinero($h['precio_venta_nuevo'])) ?> (sin cambio)</span>
                                        <?php else: ?>
                                            <?= esc(dinero($h['precio_venta_anterior'])) ?><span class="arrow">→</span><strong><?= esc(dinero($h['precio_venta_nuevo'])) ?></strong>
                                        <?php endif; ?>
                                    </td>

                                    <td class="center"><?= mostrarVariacion($h['precio_venta_anterior'], $h['precio_venta_nuevo']) ?></td>

                                    <td>
                                        <?php if (!empty($h['id_compra'])): ?>
                                            <span class="badge badge-info">Compra #<?= esc($h['numero_factura'] ?? $h['id_compra']) ?></span>
                                        <?php else: ?>
                                            <span class="badge badge-neutral">Ajuste manual</span>
                                        <?php endif; ?>
                                    </td>

                                    <td><?= esc($h['nombre_usuario']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7">
                                    <div class="empty-state">
                                        <i>🕘</i>
                                        <h4>No hay cambios registrados</h4>
                                        <p>Aún no se ha modificado ningún precio con estos filtros.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- PAGINACIÓN (conserva los filtros activos en cada enlace) -->
            <?php if ($totalPaginas > 1): ?>
                <div class="pagination">
                    <span>Página <?= (int) $pagina ?> de <?= (int) $totalPaginas ?></span>
                    <div class="pages">
                        <?php if ($pagina > 1): ?>
                            <a href="<?= esc(urlAccion('precio', 'historial', $filtrosUrl + ['pagina' => $pagina - 1])) ?>">← Anterior</a>
                        <?php else: ?>
                            <span class="disabled">← Anterior</span>
                        <?php endif; ?>

                        <?php
                        // Ventana de 5 páginas alrededor de la actual
                        $inicio = max(1, $pagina - 2);
                        $fin    = min($totalPaginas, $pagina + 2);
                        for ($i = $inicio; $i <= $fin; $i++):
                        ?>
                            <?php if ($i === $pagina): ?>
                                <span class="current"><?= $i ?></span>
                            <?php else: ?>
                                <a href="<?= esc(urlAccion('precio', 'historial', $filtrosUrl + ['pagina' => $i])) ?>"><?= $i ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>

                        <?php if ($pagina < $totalPaginas): ?>
                            <a href="<?= esc(urlAccion('precio', 'historial', $filtrosUrl + ['pagina' => $pagina + 1])) ?>">Siguiente →</a>
                        <?php else: ?>
                            <span class="disabled">Siguiente →</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div style="margin-top: 20px;">
            <a href="<?= esc(urlAccion('precio', 'tablaPrecios')) ?>" class="btn-form btn-cancel">← Volver a la lista de precios</a>
        </div>

    </main>
</body>
</html>
